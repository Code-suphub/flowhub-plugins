"""SSH CLI and private JSON bridge used by FlowHub."""
import argparse
import json
import sys
import unicodedata
from .sessions import Sessions, SSHError, config_path, read_config, find, digest, save_record

def configure_parser(parser):
    commands=parser.add_subparsers(dest='ssh_command',required=True)
    for name in ('hosts','exec','console','session','bridge','network','upload','download'):
        p=commands.add_parser(name)
        p.add_argument('--config',help='共享配置文件（默认 ~/.ssh/mcp-servers.json）')
        p.add_argument('--json',action='store_true',help='输出缩进 JSON（管道输出默认使用 JSON）')
        if name=='hosts':continue
        if name=='bridge':continue
        if name in ('upload','download'):
            p.add_argument('alias')
            p.add_argument('source',help='源文件路径；远端路径必须为绝对路径')
            p.add_argument('destination',help='目标文件路径；不会自动创建父目录')
            p.add_argument('--overwrite',action='store_true',help='覆盖目标普通文件（默认拒绝覆盖）')
            p.add_argument('--timeout',type=float,default=300,help='传输超时秒数，最大 3600')
            continue
        if name=='network':
            p.add_argument('alias')
            p.add_argument('--mode',choices=['system','direct','proxy'])
            p.add_argument('--proxy',default='')
            p.add_argument('--extra-port',action='append',type=int,default=[])
            p.add_argument('--revision',help='保存时使用读取结果中的 revision')
            continue
        if name in ('exec','console'):
            p.add_argument('alias')
        if name=='exec':
            p.add_argument('--timeout',type=float,default=60)
            p.add_argument('--command',dest='ssh_args',nargs=argparse.REMAINDER,help='在 -- 后提供命令 argv')
        if name=='session':
            sub=p.add_subparsers(dest='session_command',required=True)
            for action in ('list','start','state','exec','stop','attach'):
                q=sub.add_parser(action)
                q.add_argument('--json',action='store_true',default=argparse.SUPPRESS,help='输出缩进 JSON')
                if action!='list':q.add_argument('target')
                if action=='exec':
                    q.add_argument('--timeout',type=float,default=60)
                    q.add_argument('--command',dest='ssh_args',nargs=argparse.REMAINDER)

def bridge(request,path):
    action=request.get('action')
    if action=='init':
        import os
        from .sessions import file_lock
        path.parent.mkdir(parents=True,mode=0o700,exist_ok=True)
        with file_lock(path.with_suffix(path.suffix+'.lock')):
            if not path.exists():
                fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
                with os.fdopen(fd,'w') as out:out.write('[]\n')
            data=read_config(path)
        return {'revision':digest(data),'hosts':[{k:v for k,v in r.items() if k in ('name','host','port','username','type','readOnly','relay')} for r in data]}
    if action in ('network-read','network-save'):
        from . import network
        if action=='network-read': return network.read(path,request['alias'])
        return network.save(path,request['alias'],request['policy'],request['revision'])
    if action=='profiles':
        data=read_config(path)
        return {'revision':digest(data),'hosts':[{k:v for k,v in r.items() if k in ('name','host','port','username','type','readOnly','relay')} for r in data]}
    if action=='profile':
        row=find(path,request['alias'])
        return {'revision':digest(read_config(path)), 'profile':{k:v for k,v in row.items() if k not in ('password','passphrase')},
                'passwordAuth':bool(row.get('password'))}
    if action=='save':
        return {'revision':save_record(path,request['profile'],request['revision'])}
    s=Sessions(path)
    if action=='list':return {'sessions':s.listing()}
    if action=='start':return s.start(request['alias'])
    sid=request.get('id') or s.ident(request['alias'])
    if action=='state':
        if not s.exists(sid):return {'id':sid,'connected':False,'phase':'disconnected','paused':(s.root/(sid+'.paused')).exists(),'output':''}
        return s.advance(sid)
    if action=='stop':return s.stop(sid)
    if action=='send':return s.send(sid,request.get('text'),request.get('key'))
    if action in ('exec','collect'):
        if not s.exists(sid):
            if (s.root/(sid+'.paused')).exists():raise SSHError('会话已手动断开，请显式 start 后继续')
            s.start(request['alias'])
        return s.execute(sid,request['command'],timeout=bounded_timeout(request.get('timeout',60)),isolated=action=='collect' or request.get('isolated',False),
                         collect=action=='collect')
    raise SSHError('不支持的共享会话操作')

def bounded_timeout(value):
    value=float(value)
    if not 0<value<=600:raise SSHError('timeout 必须为 0–600 秒之间的正数')
    return value

def table(headers, rows):
    def plain(value):
        # Configuration labels must not inject terminal control sequences.
        return ''.join(c if c.isprintable() else ' ' for c in str(value))
    def width(value):
        return sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in ('W','F') else 1 for c in value)
    values=[[plain(cell) for cell in row] for row in [headers,*rows]]
    widths=[max(width(row[i]) for row in values) for i in range(len(headers))]
    for row in values:
        print('  '.join(cell+' '*(widths[i]-width(cell)) for i,cell in enumerate(row)).rstrip())

def display(result,args,path):
    human=sys.stdout.isatty() and not args.json
    if human and args.ssh_command=='hosts':
        rows=[]
        for host in result['hosts']:
            relay=host.get('type')=='relay'
            profile=host.get('relay',{})
            target=(profile.get('command','n')+' '+profile.get('target','—')) if relay else host.get('host','—')
            rows.append([host['name'],'relay' if relay else 'SSH',target,'—' if relay else host.get('port',22),
                         '—' if relay else host.get('username','—'),'仅查询' if host.get('readOnly') else '普通'])
        print(f'配置文件：{path}\n')
        table(['名称','类型','目标','端口','用户','模式'],rows)
        print(f'\n共 {len(rows)} 个连接')
    elif human and args.ssh_command=='session' and args.session_command=='list':
        rows=[]
        for session in result['sessions']:
            status='已退出' if session['dead'] else '执行中/结果未知' if session['busy'] else '终端附着' if session['attached'] else '存活'
            rows.append([session['alias'],session['type'],status,session['id'],session['config_file']])
        table(['名称','类型','状态','会话 ID','配置文件'],rows)
        print(f'\n共 {len(rows)} 个会话')
    else:
        print(json.dumps(result,ensure_ascii=False,indent=2))

def run(args):
    import shlex
    try:
        path=config_path(args.config)
        name=args.ssh_command
        if name=='bridge':
            line=sys.stdin.buffer.read(65537)
            if len(line)>65536:raise SSHError('请求超过 64 KiB')
            result=bridge(json.loads(line),path)
        elif name=='hosts':result=bridge({'action':'profiles'},path)
        elif name in ('upload','download'):
            from .transfer import transfer
            local,remote=(args.source,args.destination) if name=='upload' else (args.destination,args.source)
            result=transfer(path,args.alias,name,local,remote,overwrite=args.overwrite,timeout=args.timeout)
        elif name=='network':
            if args.mode:
                if not args.revision:raise SSHError('保存网络策略需要 --revision；请先读取当前配置')
                result=bridge({'action':'network-save','alias':args.alias,'revision':args.revision,
                    'policy':{'mode':args.mode,'proxy':args.proxy,'extraPorts':args.extra_port}},path)
            else:result=bridge({'action':'network-read','alias':args.alias},path)
        else:
            s=Sessions(path)
            if name=='session':
                action=args.session_command
                if action=='list':result={'sessions':s.listing()}
                elif action=='start':result=s.start(args.target)
                elif action=='state':result=s.advance(args.target)
                elif action=='stop':result=s.stop(args.target)
                elif action=='attach':return s.attach(args.target)
                else:
                    if not args.ssh_args:raise SSHError('请在 -- 后提供命令')
                    result=s.execute(args.target,shlex.join(args.ssh_args),timeout=bounded_timeout(args.timeout))
            elif name=='console':
                sid=s.start(args.alias)['id'];return s.attach(sid)
            else:
                if not args.ssh_args:raise SSHError('请在 -- 后提供命令')
                sid=s.start(args.alias)['id']
                result=s.execute(sid,shlex.join(args.ssh_args),timeout=bounded_timeout(args.timeout),isolated=True)
        display(result,args,path)
        return result.get('exit_code',0) if isinstance(result,dict) else 0
    except (SSHError,OSError,ValueError,KeyError,TypeError) as error:
        message=str(error) if isinstance(error,SSHError) else 'SSH 请求或配置无效'
        print(json.dumps({'error':message},ensure_ascii=False),file=sys.stderr);return 1
