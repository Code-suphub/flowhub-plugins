"""Binary-safe single-file transfers over a separate non-PTY OpenSSH channel."""
import hashlib
import math
import os
from pathlib import Path
import shlex
import stat
import subprocess
import tempfile
import uuid

from .connection import ssh_command
from .sessions import SSHError, config_path, find


COMMON = r'''
set -eu
umask 077
hash_file() {
    if command -v sha256sum >/dev/null 2>&1; then sha256sum < "$1"
    elif command -v shasum >/dev/null 2>&1; then shasum -a 256 < "$1"
    else echo 'Remote sha256sum or shasum is required' >&2; exit 1; fi
}
'''
UPLOAD = COMMON + r'''
dest=$1; expected_size=$2; expected_hash=$3; overwrite=$4; token=$5
if [ -L "$dest" ] || { [ -e "$dest" ] && [ ! -f "$dest" ]; }; then echo 'Destination must be a regular file, not a symlink' >&2; exit 1; fi
if [ "$overwrite" = no ] && [ -e "$dest" ]; then echo 'Destination exists; use --overwrite' >&2; exit 1; fi
parent=${dest%/*}; parent=${parent:-/}
stage=$(mktemp -d "$parent/.toolkit-transfer.XXXXXXXX")
trap 'rm -f "$stage/file"; rmdir "$stage"' EXIT
trap 'exit 1' HUP INT TERM
cat > "$stage/file"
size=$(wc -c < "$stage/file" | tr -d '[:space:]')
sum=$(hash_file "$stage/file"); sum=${sum%% *}
[ "$size" = "$expected_size" ] && [ "$sum" = "$expected_hash" ] || { echo 'Transfer checksum mismatch' >&2; exit 1; }
if [ "$overwrite" = yes ]; then
    [ ! -L "$dest" ] && { [ ! -e "$dest" ] || [ -f "$dest" ]; } || exit 1
    mv -f "$stage/file" "$dest"
else
    ln "$stage/file" "$dest"
fi
printf '%s %s %s\n' "$token" "$size" "$sum"
'''
DOWNLOAD = COMMON + r'''
source=$1; token=$2
[ -f "$source" ] && [ ! -L "$source" ] || { echo 'Source must be a regular file, not a symlink' >&2; exit 1; }
size=$(wc -c < "$source" | tr -d '[:space:]')
sum=$(hash_file "$source"); sum=${sum%% *}
printf '%s %s %s\n' "$token" "$size" "$sum"
cat "$source"
'''


def checksum(handle):
    result = hashlib.sha256()
    size = 0
    while chunk := handle.read(1024 * 1024):
        result.update(chunk)
        size += len(chunk)
    return size, result.hexdigest()


def local_path(value, row):
    path = Path(value).expanduser().absolute()
    if path.is_symlink():
        raise SSHError('本地文件不能是符号链接')
    path = path.resolve()
    allowed = row.get('allowedLocalPaths')
    if allowed is not None:
        if not isinstance(allowed, list) or not all(isinstance(p, str) and p for p in allowed):
            raise SSHError('allowedLocalPaths 必须是路径数组')
        if not any(path.is_relative_to(Path(p).expanduser().resolve()) for p in allowed):
            raise SSHError('本地路径不在 allowedLocalPaths 内')
    return path


def run_channel(command, script, arguments, *, source, output, timeout):
    # -T prevents terminal newline conversion. Connection/auth options stay shared.
    command = list(command)
    command[command.index('-tt')] = '-T'
    command += [shlex.join(['sh', '-c', script, 'toolkit-transfer', *arguments])]
    with tempfile.TemporaryFile() as errors:
        try:
            result = subprocess.run(command, stdin=source, stdout=output, stderr=errors,
                                    timeout=timeout, start_new_session=True)
        except subprocess.TimeoutExpired:
            raise SSHError('文件传输超时；请确认远端目标状态后再重试') from None
        if result.returncode:
            errors.seek(0)
            detail = errors.read(2048).decode('utf-8', errors='replace').strip()
            detail = ''.join(c if c.isprintable() or c == '\n' else ' ' for c in detail)
            raise SSHError('文件传输失败' + (': ' + detail if detail else ''))


def transfer(path, alias, direction, local, remote, *, overwrite=False, timeout=300):
    timeout = float(timeout)
    if not math.isfinite(timeout) or not 0 < timeout <= 3600:
        raise SSHError('文件传输 timeout 必须为 0–3600 秒之间的正数')
    if direction not in ('upload', 'download'):
        raise SSHError('不支持的文件传输方向')
    path = config_path(path)
    row = find(path, alias)
    if row.get('type', 'ssh') != 'ssh':
        raise SSHError('文件传输当前仅支持直连 SSH；relay 终端不提供二进制传输通道')
    if row.get('readOnly') or row.get('commandWhitelist'):
        raise SSHError('仅查询或 commandWhitelist 连接不允许文件传输')
    if not isinstance(remote, str) or not remote.startswith('/') or remote.endswith('/') or any(c in remote for c in '\r\n\0'):
        raise SSHError('远端必须是文件的绝对路径，不能包含换行')
    # Reject dot components so the upload staging directory is unambiguous.
    if any(part in ('.', '..') for part in remote.split('/')):
        raise SSHError('远端路径不能包含 . 或 .. 分量')
    local = local_path(local, row)
    root = Path.home() / '.cache/toolkit/ssh'
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = root.lstat()
    if root.is_symlink() or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise SSHError('会话目录必须属于当前用户且权限为 700')
    command = ssh_command(path, root, row)
    token = 'TKFILE_' + uuid.uuid4().hex
    with tempfile.TemporaryFile() as wire:
        if direction == 'upload':
            fd = os.open(local, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                os.close(fd)
                raise SSHError('上传源必须是普通文件')
            with os.fdopen(fd, 'rb') as source:
                size, sha = checksum(source)
                source.seek(0)
                run_channel(command, UPLOAD, [remote, str(size), sha, 'yes' if overwrite else 'no', token],
                            source=source, output=wire, timeout=timeout)
            wire.seek(0)
            if wire.read(256) != f'{token} {size} {sha}\n'.encode():
                raise SSHError('未收到有效的远端传输确认，请确认目标状态')
        else:
            if local.exists() and (not overwrite or not local.is_file()):
                raise SSHError('本地目标已存在；覆盖普通文件需使用 --overwrite')
            run_channel(command, DOWNLOAD, [remote, token], source=subprocess.DEVNULL, output=wire, timeout=timeout)
            wire.seek(0)
            header = wire.readline(256).decode('ascii', errors='replace').split()
            if len(header) != 3 or header[0] != token:
                raise SSHError('无效的传输响应（远端 shell 可能输出了额外内容）')
            size, sha = checksum(wire)
            if header[1:] != [str(size), sha]:
                raise SSHError('文件长度或 SHA256 校验失败，本地目标未修改')
            wire.seek(0)
            wire.readline(256)
            fd, stage = tempfile.mkstemp(prefix='.toolkit-transfer-', dir=local.parent)
            try:
                with os.fdopen(fd, 'wb') as destination:
                    while chunk := wire.read(1024 * 1024):
                        destination.write(chunk)
                    destination.flush()
                    os.fsync(destination.fileno())
                if overwrite:
                    if local.is_symlink() or (local.exists() and not local.is_file()):
                        raise SSHError('本地目标必须是普通文件')
                    os.replace(stage, local)
                else:
                    os.link(stage, local)
            finally:
                Path(stage).unlink(missing_ok=True)
    return {'alias': alias, 'direction': direction, 'local': str(local), 'remote': remote,
            'bytes': size, 'sha256': sha, 'verified': True}
