"""Standalone entry point: no toolkit import or installation needed."""
import argparse
import sys
from flowhub_ssh import __version__
from flowhub_ssh import cli, askpass

def main():
    if sys.argv[1:2] == ['askpass']:
        sys.argv.pop(1)
        return askpass.main()
    parser = argparse.ArgumentParser(prog='flowhub-ssh')
    parser.add_argument('--version', action='version', version=__version__)
    cli.configure_parser(parser)
    values = list(sys.argv[1:])
    if '--' in values:
        values[values.index('--')] = '--command'
    return cli.run(parser.parse_args(values))

if __name__ == '__main__':
    raise SystemExit(main())
