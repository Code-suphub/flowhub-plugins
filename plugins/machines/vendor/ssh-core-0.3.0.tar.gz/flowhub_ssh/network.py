"""Endpoint-scoped Mihomo Party policies; no global proxy selection changes."""
import contextlib
import copy
import glob
import http.client
import ipaddress
import json
import os
from pathlib import Path
import socket
import tempfile
import time
from urllib.parse import quote

from .sessions import SSHError, digest, file_lock, find, read_config


def atomic(path, data, mode=0o600):
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            os.fchmod(out.fileno(), mode); out.write(data); out.flush(); os.fsync(out.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def load_yaml(raw):
    yaml=yaml_module()
    try:
        value=yaml.safe_load(raw)
        if value is not None and not isinstance(value,dict): raise SSHError('Clash 配置必须为对象')
        return value or {}
    except yaml.YAMLError:
        raise SSHError('Clash 配置格式无效，请先在 Clash 中检查配置') from None


def yaml_module():
    try:
        import yaml
        return yaml
    except ImportError:
        raise SSHError('网络策略需要 PyYAML；请更新安装包') from None


class Party:
    def __init__(self, root=None, controller=None):
        self.root = Path(root or Path.home() / 'Library/Application Support/mihomo-party')
        sockets = glob.glob(f'/tmp/mihomo-party-{os.getuid()}-*.sock')
        sockets = [s for s in sockets if Path(s).stat().st_uid in (0, os.getuid()) and __import__('stat').S_ISSOCK(Path(s).stat().st_mode)]
        if controller is None and len(sockets) != 1:
            raise SSHError('未发现唯一的 Mihomo Party 本地控制接口，请先启动 Clash Party')
        self.controller = controller or sockets[0]

    def api(self, path, method='GET', data=None):
        controller = self.controller
        class Local(http.client.HTTPConnection):
            def connect(self):
                self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                self.sock.settimeout(8); self.sock.connect(controller)
        client = Local('localhost', timeout=8)
        try:
            body = json.dumps(data).encode() if data is not None else None
            client.request(method, path, body, {'Content-Type': 'application/json'})
            response = client.getresponse(); raw = response.read(16 * 1024 * 1024 + 1)
            if response.status >= 300 or len(raw) > 16 * 1024 * 1024:
                raise SSHError('Clash 本地控制接口请求失败')
            return json.loads(raw) if raw else None
        except (OSError, ValueError, http.client.HTTPException):
            raise SSHError('无法读取 Clash 本地控制接口') from None
        finally:
            client.close()

    def files(self):
        yaml = yaml_module()
        profile = load_yaml((self.root / 'profile.yaml').read_text())
        current = profile.get('current')
        if not isinstance(current, str) or not current.isalnum():
            raise SSHError('Clash 当前订阅标识无效')
        return self.root / 'rules' / (current + '.yaml'), self.root / 'work/config.yaml'

    def info(self):
        self.files()
        proxies = self.api('/proxies')['proxies']
        config = self.api('/configs')
        return {'available': True, 'provider': 'mihomo-party',
                'groups': sorted(k for k, v in proxies.items() if v.get('type') in ('Selector', 'URLTest', 'Fallback', 'LoadBalance')),
                'tun': bool(config.get('tun', {}).get('enable')), 'mode': config.get('mode'),
                'device': config.get('tun', {}).get('device')}


def policy(value, row):
    if not isinstance(value, dict): raise SSHError('网络策略格式无效')
    mode = value.get('mode', 'system')
    if mode not in ('system', 'direct', 'proxy'): raise SSHError('网络策略必须为 system、direct 或 proxy')
    if row.get('type') == 'relay' and mode != 'system':
        raise SSHError('堡垒机脚本的网络目标由脚本管理，暂不支持按目标配置 Clash 规则')
    if row.get('proxyJump') and mode != 'system':
        raise SSHError('此连接通过跳板机传输，请在跳板机连接上配置网络策略')
    ports = value.get('extraPorts', [])
    if not isinstance(ports, list) or len(ports) > 16 or any(type(p) is not int or not 1 <= p <= 65535 for p in ports):
        raise SSHError('附加端口必须为 1–65535 的整数，最多 16 个')
    proxy = value.get('proxy', '') if mode == 'proxy' else ''
    if mode == 'proxy' and (not isinstance(proxy, str) or not proxy or any(c in proxy for c in ',()\n\r')):
        raise SSHError('请选择有效的 Clash 代理组')
    return {'mode': mode, 'proxy': proxy, 'extraPorts': sorted(set(ports))}


def rules_for(row, value):
    if value['mode'] == 'system': return []
    host = row.get('host', '')
    try:
        address = ipaddress.ip_address(host)
        endpoint = ('IP-CIDR6' if address.version == 6 else 'IP-CIDR') + ',' + str(address) + ('/128' if address.version == 6 else '/32') + ',no-resolve'
    except ValueError:
        import re
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]{0,252}', host): raise SSHError('网络策略需要有效的主机地址')
        endpoint = 'DOMAIN,' + host
    target = 'DIRECT' if value['mode'] == 'direct' else value['proxy']
    ports = sorted(set([row.get('port', 22), *value['extraPorts']]))
    return [f'AND,((NETWORK,TCP),(DST-PORT,{p}),({endpoint})),{target}' for p in ports]


def system_route(row):
    route = None
    if row.get('host') and __import__('sys').platform == 'darwin':
        import subprocess
        try:
            result = subprocess.run(['/sbin/route', '-n', 'get', row['host']], capture_output=True, text=True, timeout=3)
            interface = next((line.split(':', 1)[1].strip() for line in result.stdout.splitlines() if line.strip().startswith('interface:')), None)
            route = {'interface': interface, 'note': '系统路由接口；不代表 Tailscale 底层是否使用中继'}
        except (OSError, subprocess.TimeoutExpired): pass
    return route


def read(path, alias, party=None):
    row = find(path, alias)
    value = policy(row.get('networkPolicy', {}), row)
    try:
        controller = party or Party()
        available = controller.info()
        if hasattr(controller, 'controller'):
            available['matches'] = [{'chains': c.get('chains', []), 'rule': c.get('rule'), 'port': c['metadata'].get('destinationPort')}
                for c in controller.api('/connections').get('connections', [])
                if (c['metadata'].get('destinationIP') == row.get('host') or c['metadata'].get('host') == row.get('host'))
                and str(c['metadata'].get('destinationPort')) in {str(row.get('port',22)), *map(str,value['extraPorts'])}]
    except (SSHError, OSError, ValueError) as error:
        available = {'available': False, 'groups': [], 'reason': str(error)}
    route = system_route(row)
    if available.get('available') and available.get('device'):
        available['routed'] = bool(available.get('tun') and route and route.get('interface') == available['device'])
    return {'revision': digest(read_config(path)), 'policy': value, 'clash': available, 'route': route,
            'endpoint': {'host': row.get('host'), 'port': row.get('port', 22)}, 'rules': rules_for(row, value)}


def save(path, alias, value, revision, party=None):
    """Explicit UI/CLI action. Backup and CAS all files; rollback runtime on failure."""
    from .sessions import Sessions
    sessions = Sessions(path)
    root = Path.home() / '.config/flowhub-ssh/network'
    root.mkdir(parents=True,mode=0o700, exist_ok=True)
    info=root.lstat()
    if root.is_symlink() or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise SSHError('网络策略目录必须属于当前用户且权限为 700')
    with contextlib.ExitStack() as locks:
        locks.enter_context(file_lock(path.with_suffix(path.suffix + '.lock')))
        locks.enter_context(file_lock(root / 'policies.lock'))
        rows = read_config(path)
        if digest(rows) != revision: raise SSHError('共享配置已变化，请重新读取网络策略')
        row = find(path, alias); value = policy(value, row)
        before = policy(row.get('networkPolicy', {}), row)
        if value == before: return {'revision': revision, 'policy': value, 'changed': False}
        sid = sessions.ident(alias)
        locks.enter_context(file_lock(sessions.root / (sid + '.lock'), False))
        if sessions.exists(sid): raise SSHError('请先断开此机器的共享会话，再修改网络策略；其他会话不受影响')
        party = party or Party()
        info = party.info()
        if value['mode'] != 'system' and info.get('mode','rule') != 'rule':
            raise SSHError('Clash 当前不是规则模式，目标规则不会生效；请先在 Clash 切换到规则模式')
        if value['mode'] != 'system' and info.get('device'):
            route = system_route(row)
            if not info.get('tun') or not route or route.get('interface') != info['device']:
                raise SSHError('此目标当前不经过 Clash TUN（可能由 Tailscale 接管），请使用跟随系统')
        if value['mode'] == 'proxy' and value['proxy'] not in info['groups']: raise SSHError('所选 Clash 代理组不存在')
        yaml = yaml_module(); rp, wp = party.files()
        rbytes = rp.read_bytes() if rp.exists() else b'prepend: []\nappend: []\ndelete: []\n'
        wbytes = wp.read_bytes(); rdoc = load_yaml(rbytes); wdoc = load_yaml(wbytes)
        ledger = root / (digest([str(path.resolve()), alias]) + '.json')
        previous = json.loads(ledger.read_text()) if ledger.exists() else None
        if previous and previous['rulesFile'] != str(rp):
            raise SSHError('Clash 订阅已切换，请先在原订阅恢复跟随系统，再修改策略')
        old_rules = previous['ownedRules'] if previous else []
        new_rules = rules_for(row, value)
        # Never remove manually configured or another profile's rules.
        prepend = rdoc.get('prepend', []); runtime_rules = wdoc.get('rules', [])
        for rule in old_rules:
            if rule not in prepend or rule not in runtime_rules: raise SSHError('已有托管规则被外部修改，请检查 Clash 配置')
        prepend = list(prepend); runtime_rules = list(runtime_rules)
        for rule in old_rules:
            prepend.remove(rule); runtime_rules.remove(rule)
        rdoc['prepend'] = new_rules + prepend
        wdoc['rules'] = new_rules + runtime_rules
        saved = copy.deepcopy(rows)
        next(r for r in saved if r['name'] == alias)['networkPolicy'] = value
        changes = {str(path): path.read_bytes(), str(wp): wbytes, str(rp): rbytes if rp.exists() else None,
                   str(ledger): ledger.read_bytes() if ledger.exists() else None}
        backup = root / ('backup-' + str(time.time_ns())); backup.mkdir(mode=0o700)
        for index, (name, raw) in enumerate(changes.items()):
            if raw is not None: atomic(backup / str(index), raw)
        atomic(backup / 'manifest.json', json.dumps(list(changes)).encode())
        if path.read_bytes() != changes[str(path)] or wp.read_bytes() != wbytes or (rp.exists() and rp.read_bytes() != rbytes):
            raise SSHError('配置已被其他程序修改，请重新读取')
        selections = {k: v.get('now') for k, v in party.api('/proxies')['proxies'].items() if v.get('type') == 'Selector'}
        updates = {
            str(rp): yaml.safe_dump(rdoc, allow_unicode=True, sort_keys=False).encode(),
            str(wp): yaml.safe_dump(wdoc, allow_unicode=True, sort_keys=False).encode(),
            str(path): (json.dumps(saved, ensure_ascii=False, indent=2) + '\n').encode(),
            str(ledger): json.dumps({'rulesFile': str(rp), 'ownedRules': new_rules}).encode(),
        }
        written = {}
        try:
            party.api('/configs', 'PUT', {'payload': updates[str(wp)].decode()})
            now = party.api('/proxies')['proxies']
            for group, selected in selections.items():
                if now.get(group, {}).get('now') != selected:
                    party.api('/proxies/' + quote(group, safe=''), 'PUT', {'name': selected})
            for name, raw in updates.items():
                file = Path(name)
                current = file.read_bytes() if file.exists() else None
                if current != changes[name]: raise SSHError('配置已被其他程序修改')
                atomic(file, raw); written[name] = raw
        except Exception:
            conflict = False
            for name, raw in written.items():
                file = Path(name)
                if not file.exists() or file.read_bytes() != raw:
                    conflict = True; continue
                previous = changes[name]
                if previous is None: file.unlink(missing_ok=True)
                else: atomic(file, previous)
            try:
                # Preserve external config edits detected while applying our change.
                party.api('/configs', 'PUT', {'payload': wp.read_text()})
                now = party.api('/proxies')['proxies']
                for group, selected in selections.items():
                    if now.get(group, {}).get('now') != selected:
                        party.api('/proxies/' + quote(group, safe=''), 'PUT', {'name': selected})
            except Exception:
                raise SSHError('网络策略写入失败且运行时回滚未确认，请使用私有备份恢复：' + str(backup)) from None
            if conflict: raise SSHError('检测到外部修改，未覆盖外部文件；请检查私有备份：' + str(backup)) from None
            raise SSHError('网络策略写入失败，已回滚') from None
        return {'revision': digest(saved), 'policy': value, 'changed': True, 'backup': str(backup),
                'note': '已持久化到当前 Clash 订阅；规则只影响匹配的目标和端口。已有连接可能需要重连。'}
