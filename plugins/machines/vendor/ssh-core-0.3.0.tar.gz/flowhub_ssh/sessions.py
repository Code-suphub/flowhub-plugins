"""Shared, user-owned tmux SSH/relay sessions. No MCP or GUI dependency."""
from __future__ import annotations
from .runtime import helper_command, bundled_tmux
import base64
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

DEFAULT_CONFIG = Path.home() / '.ssh/mcp-servers.json'
QUERY_COMMANDS = {'uptime', 'hostname', 'uname -a', 'df -h /', 'free -m'}

def registered_query(row, command):
    return (command.strip() in QUERY_COMMANDS
            or hashlib.sha256(command.encode()).hexdigest() in row.get('queryHashes', []))

class SSHError(Exception):
    pass

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def config_path(value=None):
    path = Path(value or DEFAULT_CONFIG).expanduser().absolute()
    if not path.is_absolute():
        raise SSHError('配置文件必须是绝对路径')
    return path

def read_config(path):
    try:
        if path.is_symlink(): raise SSHError('配置文件不能是符号链接')
        data = json.loads(path.read_text())
    except (OSError, ValueError):
        raise SSHError('无法读取 SSH 配置 JSON') from None
    if not isinstance(data, list): raise SSHError('共享配置必须是连接数组')
    names = set()
    for item in data:
        if not isinstance(item, dict): raise SSHError('连接配置结构无效')
        name = item.get('name')
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', name) or name in names:
            raise SSHError('连接别名无效或重复')
        names.add(name)
    return data

def find(path, alias):
    rows = [row for row in read_config(path) if row['name'] == alias]
    if len(rows) != 1: raise SSHError('未找到唯一连接别名')
    validate(rows[0])
    return rows[0]

def validate(row):
    if row.get('type', 'ssh') == 'relay':
        relay = row.get('relay', {})
        if not isinstance(relay, dict): raise SSHError('relay 配置无效')
        script = Path(relay.get('script', '')).expanduser()
        if not script.is_absolute() or not script.is_file() or not os.access(script, os.X_OK):
            raise SSHError('relay script 必须是可执行文件的绝对路径')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', relay.get('target', '')):
            raise SSHError('relay 目标机器无效')
        if relay.get('command', 'n') not in ('n', 's', 'v', 'c', 'k', 'o'): raise SSHError('relay 指令无效')
        return
    if row.get('type', 'ssh') != 'ssh': raise SSHError('不支持的连接类型')
    for field in ('host', 'username'):
        value = row.get(field)
        if not isinstance(value, str) or not value or value.startswith('-') or any(c.isspace() or ord(c)<32 for c in value):
            raise SSHError(f'{field} 无效')
    if type(row.get('port', 22)) is not int or not 1 <= row.get('port', 22) <= 65535: raise SSHError('port 无效')
    if row.get('proxy') or row.get('transportMode', 'exec') != 'exec': raise SSHError('此连接的 proxy/transportMode 尚不支持')
    if row.get('password') is not None and (not isinstance(row['password'], str) or any(c in row['password'] for c in '\n\r\0')):
        raise SSHError('password 格式无效')
    if row.get('password') and row.get('proxyJump'): raise SSHError('密码认证不支持 proxyJump')

@contextlib.contextmanager
def file_lock(path, blocking=True):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        os.fchmod(fd, 0o600)
        try: fcntl.flock(fd, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError: raise SSHError('此会话正在执行命令，请稍后重试') from None
        yield
    finally:
        os.close(fd)

def save_record(path, row, revision):
    validate(row)
    with file_lock(path.with_suffix(path.suffix + '.lock')):
        data = read_config(path) if path.exists() else []
        if digest(data) != revision: raise SSHError('共享配置已变化，请重新读取后保存')
        old = next((r for r in data if r['name'] == row['name']), None)
        merged = {**(old or {}), **row}
        if merged.get('networkPolicy') != (old or {}).get('networkPolicy'):
            raise SSHError('网络策略请使用 network 命令或 FlowHub 网络设置修改')
        if old and old.get('networkPolicy',{}).get('mode','system') != 'system' and any(merged.get(k)!=old.get(k) for k in ('host','port','proxyJump')):
            raise SSHError('请先将网络策略恢复为跟随系统，再修改主机地址、端口或跳板机')
        if old and old.get('password') and any(merged.get(k)!=old.get(k) for k in ('host','username','port')) and 'password' not in row:
            raise SSHError('密码连接地址已变化，请重新提供密码或清除密码认证')
        validate(merged)
        data = [merged if r['name'] == row['name'] else r for r in data]
        if old is None: data.append(merged)
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='.'+path.name, dir=path.parent)
        try:
            with os.fdopen(fd, 'w') as out:
                os.fchmod(out.fileno(), 0o600)
                json.dump(data, out, ensure_ascii=False, indent=2);out.write('\n');out.flush();os.fsync(out.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)
        return digest(data)

class Sessions:
    def __init__(self, path=None, *, state_dir=None, server='toolkit-ssh'):
        self.path = config_path(path)
        self.root = Path(state_dir or Path.home()/'.cache/toolkit/ssh')
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        info = self.root.lstat()
        if self.root.is_symlink() or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise SSHError('会话目录必须属于当前用户且权限为 700')
        self.server = server
        self.tmux = shutil.which('tmux') or bundled_tmux() or '/opt/homebrew/bin/tmux'
        if not Path(self.tmux).is_file(): raise SSHError('需要已安装的 tmux')

    def call(self, *args, optional=False):
        try:
            p = subprocess.run([self.tmux,'-L',self.server,'-f','/dev/null',*args],capture_output=True,text=True,timeout=5)
        except (OSError, subprocess.TimeoutExpired): raise SSHError('tmux 调用失败或超时') from None
        if p.returncode and not optional: raise SSHError('tmux 操作失败；请检查会话是否存在')
        return p.stdout if not p.returncode else ''

    def ident(self, alias):
        return 'tk-' + digest([str(self.path.resolve()), alias])[:24]

    def exists(self, sid):
        self.check_id(sid)
        return bool(self.call('display-message','-p','-t',sid,'#{session_name}',optional=True).strip())

    def check_id(self, sid):
        if not re.fullmatch(r'tk-[a-f0-9]{24}',sid): raise SSHError('无效的 toolkit 会话 ID')

    def option(self, sid, key):
        return self.call('show-options','-qv','-t',sid,'@toolkit-'+key).strip()

    def set(self, sid, key, value):
        self.call('set-option','-t',sid,'@toolkit-'+key,str(value))

    def listing(self):
        names = self.call('list-sessions','-F','#{session_name}',optional=True).splitlines()
        result=[]
        for sid in names:
            if re.fullmatch(r'tk-[a-f0-9]{24}',sid) and self.option(sid,'owner')=='toolkit-ssh-v1':
                result.append({'id':sid,'alias':self.option(sid,'alias'),'config_file':self.option(sid,'config'),
                               'type':self.option(sid,'type'),'attached':self.attached(sid),
                               'busy':bool(self.option(sid,'busy')),'dead':self.dead(sid)})
        return result

    def attached(self,sid):
        return self.call('display-message','-p','-t',sid,'#{session_attached}').strip()!='0'
    def dead(self,sid):
        return self.call('display-message','-p','-t',sid,'#{pane_dead}').strip()=='1'

    def owned(self,sid):
        self.check_id(sid)
        if not self.exists(sid) or self.option(sid,'owner')!='toolkit-ssh-v1': raise SSHError('共享会话不存在')
        if self.option(sid,'config') != str(self.path.resolve()): raise SSHError('会话不属于当前配置文件')
        alias=self.option(sid,'alias');row=find(self.path,alias)
        if self.option(sid,'revision')!=digest(row): raise SSHError('连接配置已变化，请断开旧会话后重新连接')
        return row

    def ssh_command(self,row):
        from .connection import ssh_command
        return ssh_command(self.path, self.root, row)

    def connection_command(self, row):
        if row.get('type') != 'relay':return self.ssh_command(row)
        relay_path=':'.join([str(Path.home()/'.asdf/shims'),str(Path.home()/'.local/bin'),'/opt/homebrew/bin','/usr/local/bin',os.environ.get('PATH','/usr/bin:/bin')])
        return ['/usr/bin/env','PATH='+relay_path,str(Path(row['relay']['script']).expanduser())]

    def start(self,alias,*,command=None):
        row=find(self.path,alias);sid=self.ident(alias)
        with file_lock(self.root/(sid+'.lock')):
            row=find(self.path,alias)
            if self.exists(sid):
                self.owned(sid)
                if self.dead(sid): raise SSHError('旧会话已退出，请先 stop 再重新 start')
                return self.state(sid)
            paused=self.root/(sid+'.paused')
            paused.unlink(missing_ok=True)
            # Create a holder pane, then record identity before spawning the connection.
            self.call('new-session','-d','-s',sid,'-x','180','-y','45','/bin/sleep 60')
            try:
                for key,value in {'owner':'toolkit-ssh-v1','alias':alias,'config':str(self.path.resolve()),
                                  'type':row.get('type','ssh'),'revision':digest(row)}.items():self.set(sid,key,value)
                self.call('set-option','-t',sid,'remain-on-exit','on')
                self.call('set-option','-t',sid,'history-limit','20000')
                args=command or self.connection_command(row)
                self.call('respawn-pane','-k','-t',sid,shlex.join(args))
            except Exception:
                self.call('kill-session','-t',sid,optional=True);raise
        return self.state(sid)

    def capture(self,sid):
        return self.call('capture-pane','-p','-J','-t',sid,'-S','-20000')

    def state(self,sid):
        row=self.owned(sid);output=self.capture(sid)
        phase='failed' if self.dead(sid) else 'busy' if self.option(sid,'busy') else 'connecting'
        if not self.dead(sid) and not self.option(sid,'busy'):
            last=next((x.strip() for x in reversed(output.splitlines()) if x.strip()),'')
            if re.search(r'[$#%]\s*$',last):phase='ready'
            elif re.search(r'(password|verification|otp|验证码|密码).*[:：]\s*$',last,re.I):phase='authenticating'
            elif row.get('type')=='relay' and '@' in last and last.endswith(' ->'):phase='gateway'
        return {'id':sid,'connected':not self.dead(sid),'phase':phase,'attached':self.attached(sid),'output':output[-65536:]}

    def advance(self,sid):
        state=self.state(sid)
        if state['phase']=='gateway' and not self.option(sid,'target-sent') and not self.attached(sid):
            with file_lock(self.root/(sid+'.lock'),False):
                if not self.option(sid,'target-sent'):
                    row=self.owned(sid);relay=row['relay'];self.set(sid,'target-sent','1')
                    self.call('send-keys','-l','-t',sid,'--',shlex.join([relay.get('command','n'),relay['target']]))
                    self.call('send-keys','-t',sid,'Enter');state['phase']='connecting'
        return state

    def send(self,sid,text=None,key=None):
        row=self.owned(sid)
        if row.get('readOnly'):raise SSHError('此连接仅允许固定查询')
        with file_lock(self.root/(sid+'.lock'),False):
            if self.attached(sid) or self.option(sid,'busy'):raise SSHError('会话被终端附着或正在执行命令')
            if key:
                if key not in ('C-c','Enter','Tab','Up','Down','Escape'):raise SSHError('不支持的按键')
                self.call('send-keys','-t',sid,key)
            else:
                if not isinstance(text,str) or len(text.encode())>8192 or any(c in text for c in '\r\n\0'):raise SSHError('输入格式无效')
                self.call('send-keys','-l','-t',sid,'--',text);self.call('send-keys','-t',sid,'Enter')
        return self.state(sid)

    def ready(self,sid,timeout):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            state=self.state(sid)
            if state['phase']=='failed':raise SSHError('SSH/relay 连接已退出；请在终端检查认证及主机指纹')
            if state['phase']=='ready':return
            if state['phase']=='gateway':
                row=self.owned(sid)
                if self.option(sid,'target-sent'):raise SSHError('会话已返回 relay 网关；请重新连接')
                self.set(sid,'target-sent','1')
                relay=row['relay'];self.call('send-keys','-l','-t',sid,'--',shlex.join([relay.get('command','n'),relay['target']]))
                self.call('send-keys','-t',sid,'Enter')
            time.sleep(.15)
        raise SSHError('连接尚未就绪；请使用 console 完成认证')

    def collect_fresh(self, sid, row, command, timeout, max_bytes):
        args = self.ssh_command(row)
        tty = args.index('-tt')
        args[tty:tty+1] = ['-T', '-o', f'ConnectTimeout={max(1, int(timeout))}']
        if not row.get('password'):
            args[tty:tty] = ['-o', 'BatchMode=yes']
        args.append(shlex.join(['sh', '-c', command]))
        with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
            try:
                process = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=output, stderr=errors,
                                         timeout=timeout, start_new_session=True)
            except subprocess.TimeoutExpired as error:
                raise SSHError('监控 SSH 连接或采集超时') from error
            except OSError as error:
                raise SSHError('无法启动监控 SSH 连接：' + (error.strerror or type(error).__name__)) from error
            output.seek(0)
            data = output.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise SSHError('命令输出超过上限')
            errors.seek(0)
            raw_error = errors.read(65537)
            detail = 'SSH 错误输出超过上限' if len(raw_error) > 65536 else raw_error.decode(errors='replace')
            for field in ('password', 'passphrase'):
                secret = row.get(field)
                if isinstance(secret, str) and secret:
                    detail = detail.replace(secret, '[已隐藏]')
            detail = ''.join(c for c in detail if c.isprintable() or c == '\n')[:2000]
        return {'id': sid, 'alias': row['name'], 'exit_code': process.returncode,
                'output': data.decode(errors='replace'), 'error_detail': detail,
                'complete': True, 'stream': 'stdout', 'reconnected': True}

    def execute(self,sid,command,*,timeout=60,max_bytes=1024*1024,isolated=False,collect=False):
        row=self.owned(sid)
        if not isinstance(command,str) or not command.strip() or len(command.encode())>8192 or '\0' in command:
            raise SSHError('命令为空、过长或含 NUL')
        query = isolated and registered_query(row, command)
        if collect and not query:raise SSHError('后台采集仅允许已登记的固定查询')
        if row.get('readOnly') and not registered_query(row, command):raise SSHError('此连接仅允许固定查询')
        whitelist=row.get('commandWhitelist')
        if whitelist and command not in whitelist:raise SSHError('命令不在连接 commandWhitelist 内')
        with file_lock(self.root/(sid+'.lock'),False):
            if self.attached(sid):raise SSHError('系统终端正在附着此会话，请先脱离终端')
            reconnected = False
            pending = self.option(sid,'busy')
            pending_query = pending and self.option(sid,'busy-query') == pending
            if self.dead(sid):
                # Never replay a command or discard an unresolved arbitrary exec.
                # A later isolated monitoring query can replace its dead transport.
                if query and (not pending or pending_query):
                    self.call('respawn-pane','-k','-t',sid,shlex.join(self.connection_command(row)))
                    self.set(sid,'busy','');self.set(sid,'busy-query','')
                    self.set(sid,'target-sent','')
                    reconnected = True
                elif collect and row.get('type', 'ssh') == 'ssh':
                    return self.collect_fresh(sid, row, command, timeout, max_bytes)
                else:
                    raise SSHError('SSH/relay 连接已退出；请检查上次执行结果后显式重新连接，relay 需完成认证')
            elif query and pending_query:
                # A query may finish after its caller timed out. Only its exact
                # completion marker proves the existing shell can accept input.
                if re.search(r'^TK_END_'+re.escape(pending)+r':\d+$', self.capture(sid), re.M):
                    self.set(sid,'busy','');self.set(sid,'busy-query','')
            if self.option(sid,'busy'):raise SSHError('上次命令状态未知，请检查并重新连接会话')
            self.ready(sid,min(timeout,30))
            token=uuid.uuid4().hex;begin='TK_BEGIN_'+token;end='TK_END_'+token
            # Persistent mode evaluates in the existing shell. Isolated mode serves monitoring.
            payload=base64.b64encode(command.encode()).decode()
            decode='printf %s '+payload+' | base64 -d'
            script=(decode+' | sh') if isolated else 'eval "$('+decode+')"'
            if row.get('type')=='relay':
                target=row['relay']['target'];short=target.split('.')[0]
                script='if [ "$(hostname)" = '+shlex.quote(target)+' ] || [ "$(hostname)" = '+shlex.quote(short)+' ]; then '+script+'; else false; fi'
            line=f"printf '\\n%s\\n' {begin}; {script}; tk_rc=$?; printf '\\n{end}:%s\\n' \"$tk_rc\""
            self.set(sid,'busy-query',token if query else '')
            self.set(sid,'busy',token)
            self.call('send-keys','-l','-t',sid,'--',line);self.call('send-keys','-t',sid,'Enter')
            deadline=time.monotonic()+timeout
            while time.monotonic()<deadline:
                output=self.capture(sid);lines=output.splitlines()
                if begin in lines:
                    start=lines.index(begin)+1
                    for index in range(start,len(lines)):
                        match=re.fullmatch(re.escape(end)+r':(\d+)',lines[index])
                        if match:
                            body='\n'.join(lines[start:index]);self.set(sid,'busy','');self.set(sid,'busy-query','')
                            if len(body.encode())>max_bytes:raise SSHError('命令输出超过上限')
                            return {'id':sid,'alias':row['name'],'exit_code':int(match[1]),'output':body,'complete':True,'stream':'pty_combined','reconnected':reconnected}
                if self.dead(sid):raise SSHError('连接已退出；命令完成状态未知')
                time.sleep(.1)
            # Keep busy marker: never allow a late completion to be mistaken for a new command.
            raise SSHError('命令超时；远端命令可能仍运行，会话已标记 busy，请检查后重新连接')

    def stop(self,sid):
        self.check_id(sid)
        if not self.exists(sid) or self.option(sid,'owner')!='toolkit-ssh-v1' or self.option(sid,'config') != str(self.path.resolve()):raise SSHError('会话不属于当前配置文件')
        with file_lock(self.root/(sid+'.lock'),False):
            self.call('kill-session','-t',sid)
            (self.root/(sid+'.paused')).touch(mode=0o600)
        return {'id':sid,'connected':False,'phase':'disconnected','paused':True,'output':'会话已断开'}

    def attach(self,sid):
        row=self.owned(sid)
        if row.get('readOnly'):raise SSHError('此连接仅允许固定查询，不允许终端')
        if self.option(sid,'busy'):raise SSHError('会话命令运行中或状态未知')
        with file_lock(self.root/(sid+'.lock'),False):
            return subprocess.call([self.tmux,'-L',self.server,'-f','/dev/null','attach-session','-t',sid])
