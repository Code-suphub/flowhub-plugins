"""Launch helpers in either an ordinary Python install or the frozen runtime."""
import os
from pathlib import Path
import sys

def helper_command(action):
    if getattr(sys, 'frozen', False):
        return ['/usr/bin/env', 'PYINSTALLER_RESET_ENVIRONMENT=1', sys.executable, action]
    return [sys.executable, '-m', 'flowhub_ssh', action]

def bundled_tmux():
    root = getattr(sys, '_MEIPASS', None)
    path = Path(root) / 'tools/tmux' if root else None
    return str(path) if path and path.is_file() else None
