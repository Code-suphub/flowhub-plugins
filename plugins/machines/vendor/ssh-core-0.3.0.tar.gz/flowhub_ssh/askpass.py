"""SSH askpass: profile-bound secrets, stdout consumed only by OpenSSH."""
import os
import sys
from .sessions import config_path, find, digest

def main():
    try:
        if 'password:' not in ' '.join(sys.argv[1:]).lower():return 1
        path=config_path(os.environ['TOOLKIT_SSH_CONFIG'])
        if path.stat().st_mode & 0o077:return 1
        row=find(path,os.environ['TOOLKIT_SSH_ALIAS'])
        if digest(row)!=os.environ['TOOLKIT_SSH_REVISION']:return 1
        password=row.get('password')
        if not password:return 1
        sys.stdout.write(password+'\n');return 0
    except Exception:return 1
if __name__=='__main__':sys.exit(main())
